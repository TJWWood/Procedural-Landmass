﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;  

public class MapGenerator : MonoBehaviour
{
    public float noiseScale;
    public float lacunarity;

    public int seed = 0;
    public Vector2 offset;

    public TerrainType[] regions;
    public HeatType[] heats;

    public float meshHeightMultiplier;
    public int octaves;
    [Range(0, 6)]
    public int levelOfDetail;
    [Range(0, 1)]
    public float persistence;
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Z))
        {
            if(drawMode == DrawMode.Mesh)
            {
                drawMode = DrawMode.HeatMap;

            }
            else
            {
                drawMode = DrawMode.Mesh;
            }
            
        }

        if (Input.GetKeyDown(KeyCode.N))
        {
            if (drawMode == DrawMode.Mesh)
            {

                noiseScale = Random.Range(200, 450);
                lacunarity = Random.Range(2, 2.5f);
                meshHeightMultiplier = Random.Range(100, 400);
                octaves = Random.Range(5, 6);
                persistence = Random.Range(0.0f, 1.0f);
                if (transform.childCount > 0)
                {
                    removeObjectsForNewGeneration();
                }
                GenerateMap();
            }
            else
            {
                GenerateHeatMap();
            }

        }

        if(Input.GetKeyDown(KeyCode.S))
        {

            seed--;
            if (transform.childCount > 0)
            {
                removeObjectsForNewGeneration();
            }
            GenerateMap();
            
        }
        else if(Input.GetKeyDown(KeyCode.W))
        {
            seed++;
            if (transform.childCount > 0)
            {
                removeObjectsForNewGeneration();
            }
            GenerateMap();
        }

        if(Input.GetKeyDown(KeyCode.F))
        {
            offset.x -= 0.1f;
            if (transform.childCount > 0)
            {
                removeObjectsForNewGeneration();
            }
            GenerateMap();
        }
        else if (Input.GetKeyDown(KeyCode.H))
        {
            offset.x += 0.1f;
            if (transform.childCount > 0)
            {
                removeObjectsForNewGeneration();
            }
            GenerateMap();
        }
        else if (Input.GetKeyDown(KeyCode.T))
        {
            offset.y -= 0.1f;
            if (transform.childCount > 0)
            {
                removeObjectsForNewGeneration();
            }
            GenerateMap();
        }
        else if (Input.GetKeyDown(KeyCode.G))
        {
            offset.y += 0.1f;
            if (transform.childCount > 0)
            {
                removeObjectsForNewGeneration();
            }
            GenerateMap();
        }

        if(Input.GetKeyDown(KeyCode.D))
        {
            if(levelOfDetail == 6)
            {
                levelOfDetail = 6;
            }
            else
            {
                levelOfDetail++;
                if (transform.childCount > 0)
                {
                    removeObjectsForNewGeneration();
                }
                GenerateMap();
            } 
        }
        else if(Input.GetKeyDown(KeyCode.E))
        {
            if(levelOfDetail == 0)
            {
                levelOfDetail = 0;
            }
            else
            {
                levelOfDetail--;
                if (transform.childCount > 0)
                {
                    removeObjectsForNewGeneration();
                }
                GenerateMap();
            }
        }
    }
    public enum DrawMode
    {
        NoiseMap,
        ColourMap,
        Mesh,
        HeatMap
    };
    public DrawMode drawMode;

    const int mapChunkSize = 241;
        
    public bool autoUpdate;

    public AnimationCurve meshHeightCurve;

    public ParticleSystem snowParticleEffect;
    public GameObject tree;

    public void GenerateMap()
    {
        float[,] noiseMap = Noise.GenerateNoiseMap(mapChunkSize, mapChunkSize, seed, noiseScale, octaves, persistence, lacunarity, offset);
        Color[] colourMap = new Color[mapChunkSize * mapChunkSize];

        for (int y = 0; y < mapChunkSize; y++)
        {
            for (int x = 0; x < mapChunkSize; x++)
            {
                float currentHeight = noiseMap[x, y];
                for (int i = 0; i < regions.Length; i++)
                {
                    if (currentHeight <= regions[i].height)
                    {
                        colourMap[y * mapChunkSize + x] = regions[i].colour;
                        break;
                    }
                }
            }
        }

        for (int y = 0; y < mapChunkSize; y++)
        {
            for (int x = 0; x < mapChunkSize; x++)
            {
                float currentHeight = noiseMap[x, y];
                if (currentHeight >= 0.45 && currentHeight <= 0.6)
                {
                    float highestNoiseHeight = 0f;
                    if (x != 0 && y != 0 && x < mapChunkSize - 1 && y < mapChunkSize - 1)
                    {
                        highestNoiseHeight = Mathf.Max(currentHeight, noiseMap[x - 1, y - 1], noiseMap[x, y + 1], noiseMap[x, y - 1], noiseMap[x + 1, y + 1]);
                    }

                    if (highestNoiseHeight == currentHeight)
                    {
                        float heightToUse = currentHeight;
                        float xToUse = x;
                        float yToUse = y;
                        Vector3 pos = new Vector3((xToUse * 10) - (mapChunkSize * 5), (heightToUse * 100) - 30, (yToUse * 10) - (mapChunkSize * 5));
                        pos = Vector3.Reflect(pos, Vector3.forward);
                        Instantiate(tree, pos, new Quaternion(), transform);
                        
                    }
                    else if (x >= mapChunkSize - 1 && y >= mapChunkSize - 1)
                    {
                        break;
                    }
                }

                if (currentHeight >= 0.85f)
                {
                    float highestNoiseHeight = 0f;
                    if (x != 0 && y != 0 && x < mapChunkSize - 1 && y < mapChunkSize - 1)
                    {
                        highestNoiseHeight = Mathf.Max(currentHeight, noiseMap[x - 1, y - 1], noiseMap[x, y + 1], noiseMap[x, y - 1], noiseMap[x + 1, y + 1]);
                    }

                    if (highestNoiseHeight == currentHeight)
                    {
                        float heightToUse = currentHeight;
                        float xToUse = x;
                        float yToUse = y;
                        Vector3 pos = new Vector3((xToUse * 10) - (mapChunkSize * 5), heightToUse * meshHeightMultiplier, (yToUse * 10) - (mapChunkSize * 5));
                        pos = Vector3.Reflect(pos, Vector3.forward);
                        Instantiate(snowParticleEffect, pos, new Quaternion(), transform);
                        snowParticleEffect.Play();
                    }
                    else if (x >= mapChunkSize - 1 && y >= mapChunkSize - 1)
                    {
                        break;
                    }

                }
            }
        }

        MapDisplay display = FindObjectOfType<MapDisplay>();
        if (drawMode == DrawMode.NoiseMap)
        {
            display.DrawTexture(TextureGenerator.TextureFromHeightMap(noiseMap));
        }
        else if (drawMode == DrawMode.ColourMap)
        {
            display.DrawTexture(TextureGenerator.TextureFromColourMap(colourMap, mapChunkSize, mapChunkSize)); ;
        }
        else if (drawMode == DrawMode.Mesh)
        {
            display.DrawMesh(MeshGenerator.GenerateTerrainMesh(noiseMap, meshHeightMultiplier, meshHeightCurve, levelOfDetail), TextureGenerator.TextureFromColourMap(colourMap, mapChunkSize, mapChunkSize));
        }
    }

    public void GenerateHeatMap()
    {
        Color[] heatMap = new Color[mapChunkSize * mapChunkSize];
        float[,] heatNoiseMap = Noise.GenerateUniformNoiseMap(mapChunkSize, mapChunkSize, 0, mapChunkSize, 0);
        float[,] heatPerlinNoiseMap = Noise.GenerateNoiseMap(mapChunkSize, mapChunkSize, seed, noiseScale, octaves, persistence, lacunarity, offset);
        for (int y = 0; y < mapChunkSize; y++)
        {
            for (int x = 0; x < mapChunkSize; x++)
            {
                float currentLoc = heatNoiseMap[x, y] * heatPerlinNoiseMap[x, y];
                for (int i = 0; i < regions.Length; i++)
                {
                    if (currentLoc <= heats[i].threshold)
                    {
                        heatMap[y * mapChunkSize + x] = heats[i].colour;
                        break;
                    }
                }
            }
        }

        MapDisplay display = FindObjectOfType<MapDisplay>();
        if (drawMode == DrawMode.HeatMap)
        {
            display.DrawTexture(TextureGenerator.TextureFromColourMap(heatMap, mapChunkSize, mapChunkSize));
        }
    }

     void removeObjectsForNewGeneration()
    {
        for(int i = 0; i < transform.childCount; i++)
        {
            GameObject.Destroy(transform.GetChild(i).gameObject);
        }
    }
    void OnValidate()
    {
        if (lacunarity < 1)
        {
            lacunarity = 1;
        }
        if(octaves < 0)
        {
            octaves = 0;
        }
    }

    [System.Serializable]
    public struct TerrainType
    {
        public string name;
        public float height;
        public Color colour;
    }

    [System.Serializable]
    public struct HeatType
    {
        public string name;
        public float threshold;
        public Color colour;
    }
}
